import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
export const revalidate = 0;
export default async function AppDetail({params}:{params:Promise<{slug:string}>}) {
  const {slug}=await params; const supabase=await createClient();
  const {data:app}=await supabase.from("apps").select("*").eq("slug",slug).eq("published",true).maybeSingle();
  if(!app) notFound();
  return <main className="wrap"><header className="nav"><Link className="brand" href="/"><span className="brandIcon">R</span><span>Reiiku<em>ID</em></span></Link><Link href="/" className="muted" style={{fontSize:12}}>← Kembali</Link></header><article className="detail"><div className="appIcon" style={{background:"#6957e8",width:66,height:66,fontSize:27}}>{app.icon_url?<img src={app.icon_url} alt="" style={{width:"100%",height:"100%",objectFit:"cover",borderRadius:15}}/>:"R"}</div><h1 style={{fontSize:28,marginBottom:5}}>{app.name}</h1><span className="muted" style={{fontSize:12}}>{app.category} · Versi {app.version}</span><p style={{color:"#777b8a",lineHeight:1.8,fontSize:14,marginTop:22}}>{app.description}</p><div className="detailMeta"><span>Ukuran: {app.size||"—"}</span><span>Unduhan: {app.downloads||0}</span></div>{app.file_url?<a className="download" href={app.file_url} target="_blank" rel="noopener noreferrer">Unduh aplikasi ↗</a>:<p className="muted" style={{fontSize:12}}>File unduhan belum tersedia.</p>}<p className="muted" style={{fontSize:11,lineHeight:1.7,marginTop:25}}>Pastikan file berasal dari sumber yang berhak mendistribusikannya. Periksa file sebelum instalasi.</p></article></main>;
}
