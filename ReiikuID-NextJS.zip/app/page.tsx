import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import Catalog from "@/components/Catalog";
import { AppItem } from "@/lib/types";
export const revalidate = 0;
export default async function Home() {
  let apps: AppItem[] = [];
  try {
    const supabase = await createClient();
    const { data } = await supabase.from("apps").select("*").eq("published", true).order("updated_at", { ascending: false });
    apps = (data ?? []) as AppItem[];
  } catch {}
  return <>
    <header className="wrap nav">
      <Link className="brand" href="/"><span className="brandIcon">R</span><span>Reiiku<em>ID</em></span></Link>
      <nav className="navlinks"><a href="#apps">Aplikasi</a><a href="#about">Tentang</a><Link href="/admin">Admin</Link></nav>
    </header>
    <main>
      <section className="wrap hero">
        <div><span className="eyebrow">ANDROID APP DIRECTORY</span><h1>Temukan aplikasi<br/><span>favoritmu.</span></h1><p>Jelajahi koleksi aplikasi dan game Android dalam satu tempat. Sederhana, cepat, dan mudah digunakan.</p><a className="primary" href="#apps">Jelajahi aplikasi&nbsp; ↗</a></div>
        <div className="heroVisual"><div className="heroTile"><strong>R</strong><span>Discover something useful</span></div></div>
      </section>
      <section className="section" id="apps"><div className="wrap"><div className="sectionHead"><div><span className="eyebrow">KOLEKSI REIIKUID</span><h2>Jelajahi aplikasi</h2></div><span className="muted" style={{fontSize:12}}>{apps.length} aplikasi</span></div><Catalog apps={apps}/></div></section>
      <section className="wrap notice" id="about"><div style={{fontSize:22,color:"#6957e8"}}>ⓘ</div><div><h3>Unduh dengan bijak</h3><p>Unduh hanya aplikasi yang dibagikan oleh pemilik atau pihak yang memiliki izin distribusi. Periksa sumber file dan izin aplikasi sebelum memasangnya. ReiikuID tidak mendukung distribusi aplikasi bajakan atau file yang dimodifikasi tanpa izin.</p></div></section>
    </main>
    <footer className="wrap footer"><span className="brand"><span className="brandIcon">R</span>Reiiku<em>ID</em></span><span>© {new Date().getFullYear()} ReiikuID</span></footer>
  </>;
}
