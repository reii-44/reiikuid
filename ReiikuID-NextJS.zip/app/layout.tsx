import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "ReiikuID — Android Apps",
  description: "Katalog aplikasi dan game Android dari ReiikuID.",
  metadataBase: new URL("https://reiikuid.vercel.app"),
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}
