-- Jalankan seluruh SQL ini di Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.apps (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  category text not null check (category in ('Aplikasi','Game')),
  version text not null default '1.0.0',
  size text,
  description text not null,
  icon_url text,
  file_url text,
  published boolean not null default true,
  downloads bigint not null default 0,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

alter table public.apps enable row level security;

drop policy if exists "Public can view published apps" on public.apps;
create policy "Public can view published apps" on public.apps
for select using (published = true);

drop policy if exists "Admins can manage apps" on public.apps;
create policy "Admins can manage apps" on public.apps
for all to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Buat dua bucket publik untuk ikon dan file yang memang boleh didistribusikan.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
 ('app-icons','app-icons',true,5242880,array['image/png','image/jpeg','image/webp']),
 ('app-files','app-files',true,104857600,array['application/vnd.android.package-archive','application/octet-stream'])
on conflict (id) do nothing;

drop policy if exists "Public read app assets" on storage.objects;
create policy "Public read app assets" on storage.objects
for select using (bucket_id in ('app-icons','app-files'));

drop policy if exists "Admins upload app assets" on storage.objects;
create policy "Admins upload app assets" on storage.objects
for insert to authenticated
with check (
 bucket_id in ('app-icons','app-files')
 and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
);

drop policy if exists "Admins delete app assets" on storage.objects;
create policy "Admins delete app assets" on storage.objects
for delete to authenticated
using (
 bucket_id in ('app-icons','app-files')
 and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
);
