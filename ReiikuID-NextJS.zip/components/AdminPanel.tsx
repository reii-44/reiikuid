"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { AppItem } from "@/lib/types";
export default function AdminPanel(){
 const supabase=createClient(); const [session,setSession]=useState(false); const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [message,setMessage]=useState(""); const [apps,setApps]=useState<AppItem[]>([]); const [busy,setBusy]=useState(false);
 const [name,setName]=useState(""); const [category,setCategory]=useState("Aplikasi"); const [version,setVersion]=useState("1.0.0"); const [size,setSize]=useState(""); const [description,setDescription]=useState(""); const [file,setFile]=useState<File|null>(null); const [icon,setIcon]=useState<File|null>(null);
 async function load(){const {data:{user}}=await supabase.auth.getUser();setSession(!!user);if(user){const {data}=await supabase.from("apps").select("*").order("updated_at",{ascending:false});setApps((data??[]) as AppItem[]);}}
 useEffect(()=>{load();const {data:{subscription}}=supabase.auth.onAuthStateChange(()=>{load()});return()=>subscription.unsubscribe();},[]);
 async function login(e:React.FormEvent){e.preventDefault();setBusy(true);setMessage("");const {error}=await supabase.auth.signInWithPassword({email,password});setMessage(error?.message??"Login berhasil.");setBusy(false);await load();}
 async function logout(){await supabase.auth.signOut();setSession(false);setApps([]);}
 async function addApp(e:React.FormEvent){e.preventDefault();setBusy(true);setMessage("");try{
   const slug=name.toLowerCase().trim().normalize("NFD").replace(/[\\u0300-\\u036f]/g,"").replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,"");
   let file_url:string|null=null,icon_url:string|null=null;
   if(file){const path=`${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;const {error}=await supabase.storage.from("app-files").upload(path,file,{upsert:false});if(error)throw error;const {data}=supabase.storage.from("app-files").getPublicUrl(path);file_url=data.publicUrl;}
   if(icon){const path=`${crypto.randomUUID()}-${icon.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;const {error}=await supabase.storage.from("app-icons").upload(path,icon,{upsert:false});if(error)throw error;const {data}=supabase.storage.from("app-icons").getPublicUrl(path);icon_url=data.publicUrl;}
   const {error}=await supabase.from("apps").insert({name,slug,category,version,size:size||null,description,file_url,icon_url,published:true});if(error)throw error;
   setMessage("Aplikasi berhasil ditambahkan.");setName("");setSize("");setDescription("");setFile(null);setIcon(null);await load();
 }catch(err){setMessage(err instanceof Error?err.message:"Gagal menyimpan aplikasi.");}finally{setBusy(false);}}
 async function removeApp(id:string){if(!confirm("Hapus data aplikasi ini?"))return;const {error}=await supabase.from("apps").delete().eq("id",id);setMessage(error?.message??"Aplikasi dihapus.");await load();}
 return <><header className="nav"><Link href="/" className="brand"><span className="brandIcon">R</span><span>Reiiku<em>ID</em></span></Link><Link href="/" className="muted" style={{fontSize:12}}>← Lihat website</Link></header><section className="panel"><div className="eyebrow">REIIKUID CONTROL CENTER</div><h1>Dashboard Admin</h1><p className="muted" style={{fontSize:13,lineHeight:1.7}}>Masuk menggunakan akun admin Supabase yang sudah kamu buat. Jangan membagikan akses admin.</p>
 {message&&<div className="alert">{message}</div>}
 {!session?<form onSubmit={login}><div className="field"><label>Email admin</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="admin@email.com"/></div><div className="field"><label>Password</label><input type="password" required value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password"/></div><button className="btn" disabled={busy}>{busy?"Memproses...":"Masuk dashboard"}</button></form>:<>
 <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}><h2 style={{fontSize:17}}>Tambah aplikasi</h2><button className="btn secondary" onClick={logout}>Keluar</button></div>
 <form onSubmit={addApp}>
 <div className="field"><label>Nama aplikasi</label><input required value={name} onChange={e=>setName(e.target.value)} placeholder="Contoh: Reiiku Tools"/></div>
 <div className="field"><label>Kategori</label><select value={category} onChange={e=>setCategory(e.target.value)}><option>Aplikasi</option><option>Game</option></select></div>
 <div className="field"><label>Versi</label><input required value={version} onChange={e=>setVersion(e.target.value)}/></div>
 <div className="field"><label>Ukuran file</label><input value={size} onChange={e=>setSize(e.target.value)} placeholder="Contoh: 25 MB"/></div>
 <div className="field"><label>Deskripsi</label><textarea required rows={3} value={description} onChange={e=>setDescription(e.target.value)}/></div>
 <div className="field"><label>Ikon aplikasi (opsional)</label><input type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>setIcon(e.target.files?.[0]??null)}/></div>
 <div className="field"><label>File APK (opsional, maks. 100 MB)</label><input type="file" accept=".apk,application/vnd.android.package-archive" onChange={e=>setFile(e.target.files?.[0]??null)}/></div>
 <button className="btn" disabled={busy}>{busy?"Menyimpan...":"Simpan aplikasi"}</button>
 </form>
 <h2 style={{fontSize:17,marginTop:35}}>Daftar aplikasi ({apps.length})</h2>
 {apps.map(app=><div className="adminRow" key={app.id}><div><strong style={{fontSize:12}}>{app.name}</strong><div className="muted" style={{fontSize:10}}>{app.category} · v{app.version}</div></div><div className="adminActions"><Link className="btn secondary" href={`/app/${app.slug}`} style={{padding:"8px 10px"}}>Lihat</Link><button className="btn danger" style={{padding:"8px 10px"}} onClick={()=>removeApp(app.id)}>Hapus</button></div></div>)}
 </>}
 </section><footer className="wrap footer"><span>ReiikuID Admin</span><span>Kelola aplikasi secara bertanggung jawab.</span></footer></>;
}
