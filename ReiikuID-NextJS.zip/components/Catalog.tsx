 "use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import { Search } from "lucide-react";
import { AppItem } from "@/lib/types";
export default function Catalog({ apps }: { apps: AppItem[] }) {
  const [query,setQuery]=useState(""); const [category,setCategory]=useState("Semua");
  const filtered=useMemo(()=>apps.filter(a=>(category==="Semua"||a.category===category)&&`${a.name} ${a.description}`.toLowerCase().includes(query.toLowerCase())),[apps,query,category]);
  return <>
    <div className="toolbar"><label className="search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Cari aplikasi atau game..."/></label><div className="filters">{["Semua","Aplikasi","Game"].map(c=><button key={c} onClick={()=>setCategory(c)} className={`filter ${category===c?"active":""}`}>{c}</button>)}</div></div>
    {filtered.length===0?<div className="empty">Belum ada aplikasi. Admin dapat menambahkan aplikasi melalui dashboard.</div>:<div className="grid">{filtered.map(app=><Link className="appCard" href={`/app/${app.slug}`} key={app.id}><div className="appTop"><div className="appIcon" style={{background:"#6957e8"}}>{app.icon_url?<img src={app.icon_url} alt="" style={{width:"100%",height:"100%",objectFit:"cover",borderRadius:15}}/>:"R"}</div><div><h3>{app.name}</h3><small>{app.category} · v{app.version}</small></div></div><p>{app.description}</p><div className="cardFoot"><span>{app.size||"Ukuran tidak dicantumkan"}</span><b>DETAIL ↗</b></div></Link>)}</div>}
  </>;
}
