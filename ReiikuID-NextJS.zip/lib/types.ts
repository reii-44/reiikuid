export type AppItem = {
  id: string;
  name: string;
  slug: string;
  category: "Aplikasi" | "Game";
  version: string;
  size: string | null;
  description: string;
  icon_url: string | null;
  file_url: string | null;
  updated_at: string;
  downloads: number;
};
